import db from "./database";

export const getAllSembríos = (callback, errorCallback) => {
  db.transaction((tx) => {
    tx.executeSql(
      `SELECT * FROM sembrios`,
      [],
      (_, { rows }) => callback(rows._array),
      (_, error) => {
        errorCallback(error);
        return false;
      }
    );
  });
};

export const getUserSembríos = (userId, callback, errorCallback) => {
  db.transaction((tx) => {
    tx.executeSql(
      `SELECT s.id, s.nombre
       FROM usuario_sembrios us
       INNER JOIN sembrios s ON us.sembrio_id = s.id
       WHERE us.usuario_id = ?`,
      [userId],
      (_, { rows }) => callback(rows._array),
      (_, error) => {
        errorCallback(error);
        return false;
      }
    );
  });
};

export const saveUserSembríos = (userId, sembríosIds, callback, errorCallback) => {
  db.transaction((tx) => {
    // Elimina los sembríos previos del usuario
    tx.executeSql(
      `DELETE FROM usuario_sembrios WHERE usuario_id = ?`,
      [userId],
      () => {
        // Inserta los nuevos sembríos seleccionados
        sembríosIds.forEach((sembríoId) => {
          tx.executeSql(
            `INSERT INTO usuario_sembrios (usuario_id, sembrio_id) VALUES (?, ?)`,
            [userId, sembríoId]
          );
        });
        callback();
      },
      (_, error) => {
        errorCallback(error);
        return false;
      }
    );
  });
};
