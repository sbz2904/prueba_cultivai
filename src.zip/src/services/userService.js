import db from "./database";

export const createUser = (nombre, email, password, callback, errorCallback) => {
  db.transaction((tx) => {
    tx.executeSql(
      `INSERT INTO usuarios (nombre, email, password) VALUES (?, ?, ?)`,
      [nombre, email, password],
      (_, result) => callback(result),
      (_, error) => {
        errorCallback(error);
        return false;
      }
    );
  });
};

export const getUserByEmailAndPassword = (email, password, callback, errorCallback) => {
  db.transaction((tx) => {
    tx.executeSql(
      `SELECT * FROM usuarios WHERE email = ? AND password = ?`,
      [email, password],
      (_, { rows }) => {
        if (rows.length > 0) {
          callback(rows._array[0]); // Devuelve el usuario encontrado
        } else {
          errorCallback("Correo o contraseña incorrectos.");
        }
      },
      (_, error) => {
        errorCallback(error);
        return false;
      }
    );
  });
};

export const getUserById = (id, callback, errorCallback) => {
  db.transaction((tx) => {
    tx.executeSql(
      `SELECT * FROM usuarios WHERE id = ?`,
      [id],
      (_, { rows }) => {
        if (rows.length > 0) {
          callback(rows._array[0]); // Devuelve el usuario encontrado
        } else {
          errorCallback("Usuario no encontrado.");
        }
      },
      (_, error) => {
        errorCallback(error);
        return false;
      }
    );
  });
};

export const updateUser = (id, nombre, callback, errorCallback) => {
  db.transaction((tx) => {
    tx.executeSql(
      `UPDATE usuarios SET nombre = ? WHERE id = ?`,
      [nombre, id],
      (_, result) => callback(result),
      (_, error) => {
        errorCallback(error);
        return false;
      }
    );
  });
};
