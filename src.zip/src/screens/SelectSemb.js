import React, { useState, useEffect } from "react";
import { StyleSheet, View, Text, FlatList, Button, TouchableOpacity, Alert } from "react-native";
import { getAllSembríos as getAllSembrios, getUserSembríos as getUserSembrios, saveUserSembríos as saveUserSembrios } from "../services/sembriosService";

const SelectSembríosScreen = ({ route }) => {
  const { userId } = route.params;
  const [sembrios, setSembrios] = useState([]);
  const [selectedSembrios, setSelectedSembrios] = useState([]);

  useEffect(() => {
    fetchSembrios();
    fetchUserSembrios();
  }, []);

  const fetchSembrios = () => {
    getAllSembrios(
      (sembrios) => setSembrios(sembrios),
      (error) => console.error("Error al obtener sembríos:", error)
    );
  };

  const fetchUserSembrios = () => {
    getUserSembrios(
      userId,
      (userSembrios) => setSelectedSembrios(userSembrios.map((s) => s.id)),
      (error) => console.error("Error al obtener sembríos del usuario:", error)
    );
  };

  const toggleSelect = (id) => {
    setSelectedSembrios((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const saveSelection = () => {
    saveUserSembrios(
      userId,
      selectedSembrios,
      () => Alert.alert("Éxito", "Sembríos guardados correctamente"),
      (error) => console.error("Error al guardar sembríos:", error)
    );
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Selecciona tus Sembríos</Text>
      <FlatList
        data={sembrios}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={[
              styles.item,
              selectedSembrios.includes(item.id) && styles.selectedItem,
            ]}
            onPress={() => toggleSelect(item.id)}
          >
            <Text>{item.nombre}</Text>
          </TouchableOpacity>
        )}
      />
      <Button title="Guardar Selección" onPress={saveSelection} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 20,
  },
  item: {
    padding: 10,
    borderWidth: 1,
    borderColor: "#ccc",
    marginBottom: 10,
    borderRadius: 5,
  },
  selectedItem: {
    backgroundColor: "#cde",
  },
});

export default SelectSembríosScreen;
